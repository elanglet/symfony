<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Security\Core\User\UserInterface;

/**
 * Auteur
 *
 * @ORM\Table(name="auteur")
 * @ORM\Entity
 *
 */
class Auteur implements UserInterface
{
    /**
     * @var string
     *
     * @ORM\Column(name="identifiant", type="string", length=50, nullable=false)
     * @ORM\Id
     */
    private $identifiant;

    /**
     * @var string
     *
     * @ORM\Column(name="mot_de_passe", type="string", length=100, nullable=false)
     */
    private $motDePasse;

    /**
     * @var string
     *
     * @ORM\Column(name="prenom", type="string", length=50, nullable=false)
     */
    private $prenom;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=50, nullable=false)
     */
    private $nom;

    public function getIdentifiant(): ?string
    {
        return $this->identifiant;
    }

    /**
     * @param string $identifiant
     */
    public function setIdentifiant(string $identifiant): void
    {
        $this->identifiant = $identifiant;
    }

    public function getMotDePasse(): ?string
    {
        return $this->motDePasse;
    }

    public function setMotDePasse(string $motDePasse): self
    {
        $this->motDePasse = $motDePasse;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }


    public function getRoles()
    {
        // Méthode qui renvoi un tableau contenant les rôles de l'utilisateur authentifié.
        return ['ROLE_AUTEUR'];
    }

    public function getPassword()
    {
        return $this->motDePasse;
    }

    public function getSalt()
    {
        // Renvoi le sel pour le chiffrement du mot de passe.
    }

    public function eraseCredentials()
    {
        // Effacer de l'objet la représentation du mot de passe en clair.
    }

    public function getUsername()
    {
        return $this->identifiant;
    }

}
