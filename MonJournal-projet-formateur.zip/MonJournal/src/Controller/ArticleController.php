<?php

namespace App\Controller;

use App\Entity\Article;
use App\Model\ArticleService;
use App\Model\AuteurService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;

class ArticleController extends AbstractController
{
    // Attribut référencant ArticleService
    private $articleService;
    private $auteurService;

    // Serialiseur JSON
    private $serializer;

    // Constructeur pour l'injection de dépendance : ArticleService
    public function __construct(ArticleService $articleService, AuteurService $auteurService, SerializerInterface $serializer) {
        $this->articleService = $articleService;
        $this->auteurService = $auteurService;
        $this->serializer = $serializer;
    }

    /**
     * @Route("/articles", name="article_all", methods={"GET"})
     */
    // #[Route('/articles', name: 'article_all', methods: ['GET'])]
    public function all(): Response
    {
        try {
            $listeDesArticles = $this->articleService->rechercherTousLesArticles();

            // Sérialisation du tableau d'objet en JSON
            $listeDesArticlesJSON = $this->serializer->serialize($listeDesArticles, 'json');

            // dump($listeDesArticlesJSON);

            // On retourne une réponse au format JSON
            return new JsonResponse(
                $listeDesArticlesJSON,                // Les données de la réponse
                Response::HTTP_OK,              // Code de réponse HTTP
                [],                                   // Entête de réponse
                true                             // Est-ce que les données renvoyées sont déjà en JSON ?
            );
        }
        catch(\Exception $e) {
            return new JsonResponse(
                ['message' => $e->getMessage()],
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }

    /**
     * @Route("/article/{id}", name="article_show", requirements={"id"="\d+"}, methods={"GET"})
     */
    // #[Route('/article/{id}', name: 'article_show', requirements: ['id' => '\d+'], methods: ['GET'])]
    public function show(int $id): Response
    {
        try {
            $article = $this->articleService->rechercherArticleParId($id);

            $articleJson = $this->serializer->serialize($article, 'json');

            return new JsonResponse(
                $articleJson,
                Response::HTTP_OK,
                [],
                true
            );
        }
        catch (\Exception $e) {
            return new JsonResponse(
                ['message' => $e->getMessage()],
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }

    /**
     * @Route("/article/today", name="article_today", methods={"GET"})
     */
    // #[Route('/article/today', name: 'article_today', methods: ['GET'])]
    public function today(): Response {
        try {
            $articlesDuJour = $this->articleService->rechercherArticleDuJour();

            $articlesDuJourJson = $this->serializer->serialize($articlesDuJour, 'json');

            return new JsonResponse(
                $articlesDuJourJson,
                Response::HTTP_OK,
                [],
                true
            );
        }
        catch (\Exception $e) {
            return new JsonResponse(
                ['message' => $e->getMessage()],
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }

    /**
     * @Route("/article", name="article_add", methods={"POST"})
     */
    // #[Route('/article/add', name: 'article_add', methods: ['POST'])]
    public function add(Request $request): Response {
       try {
            // On contrôle le type de contenu reçu
            if($request->getContentType() === 'json') {

                // On récupère le contenu de la requête
                $json = $request->getContent();

                // On désérialise en objet Article
                $article = $this->serializer->deserialize($json, Article::class, 'json');

                // On créé la date du moment T pour l'ajouter à l'objet
                $date = \DateTime::createFromFormat("Y-m-d H:i:s", date("Y-m-d H:i:s"));
                $article->setDatePublication($date);

                // On rafraichit l'objet Auteur depuis la base de données pour assurer l'insertion de l'article.
                $auteur = $this->auteurService->rechercherAuteurParIdentifiant($article->getAuteur()->getIdentifiant());
                $article->setAuteur($auteur);

                // On insert l'objet. A l'issue de l'insertion on a un objet qui a été 'hydraté' par Doctrine.
                // L'id à été mis à jour de la valeur de clé primaire calculée.
                $this->articleService->ajouterArticle($article);

                $articleJSON = $this->serializer->serialize($article, 'json');

                return new JsonResponse(
                    $articleJSON,
                    Response::HTTP_CREATED,
                    ['Location' => $this->generateUrl('article_show', ['id' => $article->getId()])],  // Bonne pratique : Renvoyer un lien vers l'URL de l'objet inséré.
                    true
                );
            }
            else {
                return new JsonResponse(
                    ['message' => "Erreur de format dans la requête."],
                    Response::HTTP_BAD_REQUEST
                );
            }
        }
        catch(\Exception $e) {
            return new JsonResponse(
                ['message' => $e->getMessage()],
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }

    /**
     * @Route("/article", name="article_modify", methods={"PUT"})
     */
    // #[Route('/article', name: 'article_modify', methods: ['PUT'])]
    public function modify(Request $request): Response {
        try {
            if($request->getContentType() === 'json') {
                $articleJson = $request->getContent();
                $article = $this->serializer->deserialize($articleJson, Article::class, 'json');

                $this->articleService->modifierArticle($article);

                $articleJSON = $this->serializer->serialize($article, 'json');

                return new JsonResponse(
                    $articleJSON,
                    Response::HTTP_OK,
                    ['Location' => $this->generateUrl('article_show', ['id' => $article->getId()])],  // Bonne pratique : Renvoyer un lien vers l'URL de l'objet inséré.
                    true
                );
            }
            else {
                return new JsonResponse(
                    ['message' => "Erreur de format dans la requête."],
                    Response::HTTP_BAD_REQUEST
                );
            }
        }
        catch (\Exception $e) {
            return new JsonResponse(
                ['message' => $e->getMessage()],
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }

    /**
     * @Route("/article/{id}", name="article_delete", requirements={"id"="\d+"}, methods={"DELETE"})
     */
    // #[Route('/article/{id}', name: 'article_delete', requirements: ['id' => '\d+'], methods: ['DELETE'])]
    public function delete(int $id): Response {
        try {
            $this->articleService->supprimerArticle($id);

            return new JsonResponse(
                ['message' => "Suppression Ok."],
                Response::HTTP_OK,
                ['Location' => $this->generateUrl('article_all')]  // Bonne pratique : Renvoyer un lien vers l'URL de l'objet inséré.
            );
        }
        catch (\Exception $e) {
            return new JsonResponse(
                ['message' => $e->getMessage()],
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }
}
