<?php

namespace App\Controller;

use App\Entity\Auteur;
use App\Model\AuteurService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;

class AuteurController extends AbstractController
{
    private $auteurService;
    private $serializer;

    public function __construct(AuteurService $auteurService, SerializerInterface $serializer) {
        $this->auteurService = $auteurService;
        $this->serializer = $serializer;
    }

    /**
     * @Route("/auteur", name="auteur_add", methods={"POST"})
     */
    // #[Route('/auteur/add', name: 'auteur_add', methods: ['POST'])]
    public function add(Request $request): Response
    {
        try {
            if($request->getContentType() === 'json') {
                $json = $request->getContent();
                $auteur = $this->serializer->deserialize($json, Auteur::class, 'json');
                $this->auteurService->ajouterAuteur($auteur);

                return new JsonResponse(
                    ['message' => "Auteur créé."],
                    Response::HTTP_CREATED,
                    ['Location' => $this->generateUrl('auteur_show', ['identifiant' => $auteur->getIdentifiant()])]
                );
            }
            else {
                return new JsonResponse(
                    ['message' => "Erreur de format dans la requête."],
                    Response::HTTP_BAD_REQUEST
                );
            }
        }
        catch (\Exception $e) {
            return new JsonResponse(
                ['message' => $e->getMessage()],
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }

    /**
     * @Route("/auteurs", name="auteur_all", methods={"GET"})
     */
    // #[Route('/auteurs', name: 'auteur_all', methods: ['GET'])]
    public function all(): Response
    {
        try {
            $listeDesAuteurs = $this->auteurService->rechercherTousLesAuteurs();

            $listeDesAuteursJson = $this->serializer->serialize($listeDesAuteurs, 'json');

            return new JsonResponse(
                $listeDesAuteursJson,
                Response::HTTP_OK,
                [],
                true
            );
        }
        catch (\Exception $e) {
            return new JsonResponse(
                ['message' => $e->getMessage()],
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }

    /**
     * @Route("/auteur/{identifiant}", name="auteur_show", methods={"GET"})
     */
    // #[Route('/auteur/{identifiant}', name: 'auteur_show', methods: ['GET'])]
    public function show(string $identifiant): Response
    {
        try {
            $auteur = $this->auteurService->rechercherAuteurParIdentifiant($identifiant);

            $auteurJson = $this->serializer->serialize($auteur, 'json');

            return new JsonResponse(
                $auteurJson,
                Response::HTTP_OK,
                ['Location' => $this->generateUrl('auteur_all')],
                true
            );
        }
        catch(\Exception $e) {
            return new JsonResponse(
                ['message' => $e->getMessage()],
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }

    /**
     * @Route("/auteur/{nom}/{prenom}", name="auteur_showbyname", methods={"GET"})
     */
    // #[Route('/auteur/{nom}/{prenom}', name: 'auteur_showbyname', methods: ['GET'])]
    public function showByName(string $nom, string $prenom): Response
    {
        try {
            $lesAuteurs = $this->auteurService->rechercherAuteurParNomEtPrenom($nom, $prenom);

            $lesAuteursJson = $this->serializer->serialize($lesAuteurs, 'json');

            return new JsonResponse(
                $lesAuteursJson,
                Response::HTTP_OK,
                ['Location' => $this->generateUrl('auteur_all')],
                true
            );
        }
        catch(\Exception $e) {
            return new JsonResponse(
                ['message' => $e->getMessage()],
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }
}
