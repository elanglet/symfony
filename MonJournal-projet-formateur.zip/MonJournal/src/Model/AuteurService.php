<?php

namespace App\Model;

use App\Entity\Auteur;
use Doctrine\ORM\EntityManagerInterface;

class AuteurService
{
    // Attribut qui référence l'objet EntityManager de Doctrine
    private $em;

    // Constructeur qui va recevoir en paramètre l'EntityManager
    // L'objet sera automatiquement injecté par le ServiceContainer de Symfony
    public function __construct(EntityManagerInterface $em) {
        $this->em = $em;
    }

    public function ajouterAuteur(Auteur $auteur): void {
        try {
            $this->em->persist($auteur);
            $this->em->flush();
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur lors de l'ajout de l'auteur.", 0, $e);
        }
    }

    public function rechercherTousLesAuteurs(): array {
        try {
            return $this->em->getRepository('App:Auteur')->findAll();
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur lors la récupération de la liste des auteurs.", 0, $e);
        }
    }

    public function rechercherAuteurParIdentifiant(string $identifiant): Auteur {
        try {
            $auteur = $this->em->getRepository('App:Auteur')->find($identifiant);

            if($auteur == null)
                throw new \Exception("Auteur introuvable.");

            return $auteur;
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur lors la récupération de l'auteur.", 0, $e);
        }
    }

    public function rechercherAuteurParNomEtPrenom(string $nom, string $prenom): array
    {
        try {
            $dql = "SELECT a FROM App:Auteur a WHERE a.nom = :leNom AND a.prenom = :lePrenom";

            $query = $this->em->createQuery($dql);

            $query->setParameter('leNom', $nom);
            $query->setParameter('lePrenom', $prenom);

            return $query->getResult();

            // Ou bien :
            //
            // return $this->em->getRepository('App:Auteur')->findBy(['nom' => $nom, 'prenom' => $prenom]);
        }
        catch (\Exception $e) {
            throw new \Exception("Erreur lors la récupération des auteurs.", 0, $e);
        }
    }
}