<?php

namespace App\Model;

use App\Entity\Article;
use Doctrine\ORM\EntityManagerInterface;
use PHPUnit\Exception;
use function PHPUnit\Framework\throwException;

class ArticleService
{
    // Attribut qui référence l'objet EntityManager de Doctrine
    private $em;

    // Constructeur qui va recevoir en paramètre l'EntityManager
    // L'objet sera automatiquement injecté par le ServiceContainer de Symfony
    public function __construct(EntityManagerInterface $em) {
        $this->em = $em;
    }

    public function ajouterArticle(Article $article) : void {
        try {
            $this->em->persist($article);
            $this->em->flush();
        }
        catch(\Exception $e) {
            // Erreur Doctrine...
            // Logger l'erreur...
            // Déclencher une exception de niveau métier avec un message adapté.
            throw new \Exception("Erreur lors de l'ajout de l'article.", 0, $e);
        }
    }

    public function modifierArticle(Article $article) : void {
        try {
            $this->em->merge($article);
            $this->em->flush();
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur lors de la modification de l'article.", 0, $e);
        }
    }

    public function supprimerArticle(int $id) : void {
        try {
            // On récupère le Repository
            $repo = $this->em->getRepository('App:Article');
            // On récupère un article par sa clé primaire
            $article = $repo->find($id);

            if($article == null)
                throw new \Exception("Suppression impossible, l'article n'existe pas.");

            // On supprime l'article
            $this->em->remove($article);
            $this->em->flush();
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur lors de la suppression de l'article.", 0, $e);
        }
    }

    public function rechercherTousLesArticles() : array {
        try {
            $repo = $this->em->getRepository('App:Article');
            // $repo = $this->em->getRepository('App\Entity\Article');
            return $repo->findAll();

            /*
             *      return $this->em->getRepository('App:Article')->findAll();
             */
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur lors de la récupération de tous les articles.", 0, $e);
        }
    }

    public function rechercherArticleParId(int $id) : Article {
        try {
            $article = $this->em->getRepository('App:Article')->find($id);

            if ($article == null)
                throw new \Exception("Article introuvable.");

            return $article;
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur lors de la récupération de l'article.", 0, $e);
        }
    }

    public function rechercherArticleDuJour() : array {
        try {
            /*
             * datePublication ->   2022-03-29 15:07:32
             *
             *
             * SQL : SELECT * FROM article WHERE date_publication LIKE '2022-03-29%'
             */

            // $dql = "SELECT a FROM App:Article WHERE a.datePublication LIKE '" . date('Y/m/d') . "%'";
            // A eviter : Sécurité, Performances, lisibilité !

            // Requête paramétrée :
            $dql = "SELECT a FROM App:Article a WHERE a.datePublication LIKE :theDate";
            // Créer la requête DQL (préparation)
            $query = $this->em->createQuery($dql);

            // Donner la valeur au(x) paramètre(s)
            $query->setParameter('theDate', date('Y-m-d') . "%");  // Le nom du paramètre s'écrit sans les :

            // Exécuter la requête et retourner les resultats
            return $query->getResult();
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur lors de la récupération des articles du jour.", 0, $e);
        }
    }

}
